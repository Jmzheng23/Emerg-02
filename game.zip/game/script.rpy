﻿# 《生命钟王国：急诊指挥官》 - 进阶模块

define narrator = Character("旁白", what_size=30, who_size=40)
define host = Character("主持人", what_size=30, who_size=40, color="#FF6B6B")
define volunteer = Character("志愿者", what_size=30, who_size=40, color="#4ECDC4")
define player = Character("指挥官", what_size=30, who_size=40, color="#45B7D1")

# 团队成员
define ed_doctor = Character("急诊主治医生", what_size=28, who_size=38, color="#FF9E6D")
define ed_nurse = Character("急诊专科护士", what_size=28, who_size=38, color="#95E1D3")
define rt_therapist = Character("呼吸治疗师", what_size=28, who_size=38, color="#FECEAB")
define emt_tech = Character("急救技师", what_size=28, who_size=38, color="#FFC8A2")

# 患者
define patient = Character("患者-李明", what_size=30, who_size=40, color="#A8E6CF")

# 系统
define system = Character("系统", what_size=30, who_size=40, color="#AAA")

define audio.bgm_main = "audio/bgm_main.mp3"

# 图像定义
image black = "#000"
image white = "#FFF"
image bg_er_entrance = "images/er_entrance.png"
image bg_er_resus = "images/er_resus.png"
image bg_er_control = "images/er_control.png"
image bg_monitor = "images/monitor.png"
image bg_team_select = "images/team_select.png"


# 角色头像（使用占位）
image host_img = "images/host.png"
image volunteer_img = "images/volunteer.png"
image ed_doctor_img = "images/doctor.png"
image ed_nurse_img = "images/nurse.png"
image rt_therapist_img = "images/therapist.png"
image emt_tech_img = "images/tech.png"

# 游戏变量
init python:
    team_selection = []  # 已选择的团队成员
    team_points = {
        "决策力": 0,
        "执行效率": 0,
        "氧合支持": 0,
        "支援速度": 0
    }
    patient_status = {
        "gcs": 3,  # Glasgow昏迷评分
        "hr": 110,  # 心率
        "bp": "85/50",  # 血压
        "rr": 8,  # 呼吸频率（呼吸机支持）
        "spo2": 92,  # 血氧饱和度
        "temp": 38.5,  # 体温
        "血糖": 4.5  # mmol/L
    }
    diagnosis_found = False
    diagnosis_correct = False
    time_elapsed = 0  # 抢救耗时（分钟）
    action_points = 10  # 行动点

# 游戏开始
label start:
    scene black
    play music bgm_main
    
    narrator "《生命钟王国：急诊指挥官》"
    narrator "进阶模块 - 院内抢救指挥"
    
    show bg_er_entrance with dissolve
    
    host "欢迎来到急诊指挥官模拟系统！"
    host "这是一个为完成基础生命支持学习后的进阶模块。"
    host "今天，你将扮演急诊抢救团队的指挥官，面对一个复杂危重病例。"
    
    show host_img at right with dissolve
    host "我是你的系统主持人，将引导你完成整个抢救过程。"
    show volunteer_img at left with dissolve
    volunteer "我是医疗志愿者，将协助你进行团队操作和记录。"
    
    player "准备好了！请介绍病例情况。"
    
    host "病例背景：患者李明，18岁男性，在校大学生。"
    host "凌晨3点被室友发现意识丧失倒在电脑前，之前连续熬夜打游戏72小时。"
    volunteer "院前急救记录："
    volunteer "• 室友发现后立即拨打120"
    volunteer "• 同学A实施高质量CPR（按压深度5-6cm，频率100-120次/分）"
    volunteer "• 同学B取来校园AED，分析后建议电击，实施一次200J电击"
    volunteer "• 急救车到达时患者恢复自主心跳，但意识未恢复"
    volunteer "• 转运途中给予气管插管、建立静脉通路"
    
    host "现在，救护车即将抵达你所在的急诊中心。"
    host "抢救倒计时开始！"
    
    jump team_selection_scene

# 团队组建场景
label team_selection_scene:
    scene bg_team_select with dissolve
    host "第一步：组建你的抢救团队"
    host "你作为BLS团队的领导者，需要从资源池中选择4名核心成员。"
    host "注意：每个角色有技能点加成和数量限制。"
    
    narrator "可用的团队成员："
    
    # 重置选择
    $ team_selection = []
    $ team_points = {"决策力": 0, "执行效率": 0, "氧合支持": 0, "支援速度": 0}
    
    # 选择第一个角色（急诊主治医生-必选）
    host "首先，你需要选择一名急诊主治医生："
    menu:
        "选择急诊主治医生（必选，限1名）":
            $ team_selection.append("急诊主治医生")
            $ team_points["决策力"] += 5
            ed_doctor "已就位！随时准备进行高级气道管理和关键决策。"
    
    # 选择第二、第三个角色（护士，可选2名）
    host "现在选择专科护士（最多可选2名）："
    $ nurses_selected = 0
    
    label nurse_selection_loop:
        if nurses_selected >= 2:
            jump after_nurse_selection
            
        menu:
            "选择急诊专科护士（还可选择[2 - nurses_selected]名）":
                if "急诊专科护士" in team_selection:
                    $ nurses_count = team_selection.count("急诊专科护士")
                    if nurses_count < 2:
                        $ team_selection.append("急诊专科护士")
                        $ team_points["执行效率"] += 3
                        $ nurses_selected += 1
                        ed_nurse "护士[nurses_selected]号就位！准备建立静脉通路和给药。"
                        jump nurse_selection_loop
                    else:
                        host "已达最大选择数量（2名）。"
                        jump nurse_selection_loop
                else:
                    $ team_selection.append("急诊专科护士")
                    $ team_points["执行效率"] += 3
                    $ nurses_selected += 1
                    ed_nurse "护士就位！准备建立静脉通路和给药。"
                    jump nurse_selection_loop
            
            "暂不选择更多护士":
                jump after_nurse_selection
    
    label after_nurse_selection:
    
    # 计算剩余名额
    $ remaining_slots = 4 - len(team_selection)
    
    if remaining_slots > 0:
        host "还有[remaining_slots]个名额，请选择其他专业成员："
        
        # 创建选择菜单
        menu:
            "呼吸治疗师（限1名）":
                $ team_selection.append("呼吸治疗师")
                $ team_points["氧合支持"] += 4
                rt_therapist "呼吸治疗师就位！准备管理呼吸机和调整氧合参数。"
                $ remaining_slots -= 1
            
            "急救技师（可选1名）":
                $ team_selection.append("急救技师")
                $ team_points["支援速度"] += 2
                emt_tech "急救技师就位！准备操作设备和协助搬运。"
                $ remaining_slots -= 1
            
            "完成团队组建":
                pass
    
    # 显示最终团队配置
    scene bg_er_control with dissolve
    host "团队组建完成！"
    narrator "你的抢救团队："
    
    python:
        for member in team_selection:
            renpy.say(narrator, f"• {member}")
    
    narrator "\n团队技能点数："
    
    python:
        for skill, points in team_points.items():
            renpy.say(narrator, f"• {skill}: {points}点")
    
    host "团队组建评价："
    if team_points["决策力"] >= 5 and team_points["执行效率"] >= 6:
        host "优秀的团队配置！决策力和执行力都很强。"
    elif "呼吸治疗师" in team_selection and "急救技师" in team_selection:
        host "完整的专业团队，能够应对各种突发情况。"
    else:
        host "基础团队配置，可能需要更高效的协作。"
    
    host "救护车已抵达，患者正在转运至复苏室！"
    
    jump decision_point_1

# ========== 决策点1：初步评估与持续生命支持 ==========
label decision_point_1:
    scene bg_er_resus with dissolve
    play sound "ambulance_siren.mp3" fadein 1.0
    
    narrator "【时间：+0分钟】"
    narrator "救护车抵达急诊中心，患者被快速转运至复苏室。"
    
    show bg_monitor at top with dissolve
    narrator "监护仪显示："
    narrator "• 心率：110次/分，窦性心动过速"
    narrator "• 血压：85/50 mmHg"
    narrator "• 血氧饱和度：92%%（呼吸机辅助）"  # 使用%%转义%
    narrator "• 体温：38.5°C"
    
    host "决策点1：初步评估与持续生命支持"
    host "患者处于危重状态，你需要立即下达指令。"
    
    # 决策1-1：交接评估
    menu decision_1_1:
        "首先，你应该："
        
        "立即开始ABCDE系统评估":
            $ action_points -= 1
            player "立即进行ABCDE系统评估！"
            ed_doctor "开始评估："
            ed_doctor "A（气道）：已建立气管插管，位置良好"
            ed_doctor "B（呼吸）：呼吸频率8次/分（呼吸机设置），双肺呼吸音对称"
            ed_doctor "C（循环）：血压低，心动过速，末梢循环差"
            ed_doctor "D（意识）：GCS评分3分（E1V1M1），瞳孔对光反射迟钝"
            ed_doctor "E（暴露与环境）：体温升高，无明显外伤"
            narrator "评估完成，发现循环不稳定和意识障碍。"
            $ team_points["决策力"] += 1
        
        "先获取完整病史":
            $ action_points -= 1
            player "先了解完整病史！"
            ed_nurse "向急救人员了解：患者连续熬夜打游戏72小时，突发意识丧失。"
            ed_nurse "既往体健，无已知疾病史。"
            narrator "获取了关键病史信息。"
            $ team_points["执行效率"] += 1
        
        "立即进行实验室检查":
            $ action_points -= 2
            player "立即采血送检！"
            if "急诊专科护士" in team_selection:
                ed_nurse "立即采血：血常规、生化、凝血功能、血气分析、毒物筛查。"
                narrator "血样已送检，预计15分钟出结果。"
                $ team_points["执行效率"] += 2
            else:
                narrator "没有专科护士，采血效率较低..."
                $ team_points["执行效率"] -= 1
    
    # 决策1-2：循环支持
    host "患者血压85/50，需要循环支持！"
    
    menu decision_1_2:
        "对于低血压，你的处理策略是："
        
        "快速静脉输液扩容":
            $ action_points -= 2
            player "建立第二条静脉通路，快速输注晶体液500ml！"
            if "急诊专科护士" in team_selection:
                ed_nurse "建立中心静脉通路，开始快速输液。"
                narrator "血压上升至90/55 mmHg。"
                $ patient_status["bp"] = "90/55"
                $ team_points["执行效率"] += 2
            else:
                narrator "输液速度较慢，效果有限。"
                $ team_points["执行效率"] -= 1
        
        "使用血管活性药物":
            $ action_points -= 3
            player "准备多巴胺静脉泵入，从5μg/kg/min开始。"
            if team_points["决策力"] >= 6:
                ed_doctor "多巴胺开始泵入，监测血压变化。"
                narrator "血压上升至95/60 mmHg。"
                $ patient_status["bp"] = "95/60"
                $ team_points["决策力"] += 2
            else:
                narrator "决策力不足，血管活性药物使用不够精准。"
                $ team_points["决策力"] -= 1
        
        "等待补液反应后再决定":
            $ action_points -= 1
            player "先给予250ml液体负荷试验，观察反应。"
            narrator "等待5分钟后，血压无明显改善。"
            $ patient_status["bp"] = "87/52"
            $ time_elapsed += 5
    
    # 决策1-3：氧合管理
    host "血氧饱和度92%%，需要优化氧合！"  # 使用%%转义%
    
    menu decision_1_3:
        "如何调整呼吸机参数？"
        
        "增加FiO2至100%%":  # 使用%%转义%
            $ action_points -= 1
            player "将吸入氧浓度提高至100%%！"  # 使用%%转义%
            if "呼吸治疗师" in team_selection:
                rt_therapist "FiO2调至100%%，监测氧合指数。"  # 使用%%转义%
                narrator "血氧饱和度上升至98%%，但需警惕氧中毒风险。"  # 使用%%转义%
                $ patient_status["spo2"] = 98
                $ team_points["氧合支持"] += 2
            else:
                narrator "没有呼吸治疗师，参数调整不够精准。"
                $ patient_status["spo2"] = 94
        
        "调整PEEP至8-10cmH2O":
            $ action_points -= 2
            player "设置PEEP 8cmH2O，改善氧合。"
            if team_points["氧合支持"] >= 4:
                rt_therapist "PEEP调至8cmH2O，监测血流动力学影响。"
                narrator "血氧饱和度上升至96%%，血压稳定。"  # 使用%%转义%
                $ patient_status["spo2"] = 96
                $ patient_status["bp"] = "92/58"
                $ team_points["氧合支持"] += 3
            else:
                narrator "氧合支持能力不足，效果一般。"
                $ patient_status["spo2"] = 93
        
        "进行肺保护性通气策略":
            $ action_points -= 3
            player "实施肺保护性通气：潮气量6ml/kg，平台压<30cmH2O。"
            if team_points["氧合支持"] >= 5:
                rt_therapist "执行肺保护性通气策略，监测气道压力。"
                narrator "氧合改善，肺损伤风险降低。"
                $ patient_status["spo2"] = 95
                $ team_points["氧合支持"] += 4
            else:
                narrator "团队氧合支持能力有限，策略执行不完整。"
                $ team_points["氧合支持"] -= 1
    
    # 实验室结果回报
    narrator "【时间：+15分钟】"
    $ time_elapsed += 15
    
    host "实验室检查结果回报："
    narrator "• 血气分析：pH 7.25，PaCO2 30mmHg，PaO2 85mmHg，乳酸8.2mmol/L"
    narrator "• 血常规：WBC 18.5×10^9/L，中性粒细胞百分比92%%"  # 使用%%转义%
    narrator "• 生化：肌酸激酶 5200 U/L，肌酐 180 μmol/L"
    narrator "• 电解质：血钾 3.2 mmol/L，血钠 135 mmol/L"
    narrator "• 血糖：4.5 mmol/L"
    narrator "• 毒物筛查：阴性"
    
    player "代谢性酸中毒合并高乳酸血症！提示组织灌注不足。"
    player "白细胞和肌酸激酶显著升高...需要思考可能的原因。"
    
    jump decision_point_2

# ========== 决策点2：病因探查与精准干预 ==========
label decision_point_2:
    scene bg_er_resus with dissolve
    
    narrator "【时间：+[time_elapsed]分钟】"
    host "决策点2：病因探查与精准干预"
    host "患者年轻男性，突发意识丧失，院前复苏成功。"
    host "现在需要找出导致心脏骤停的根本原因！"
    
    # 展示当前状态
    show bg_monitor at top with dissolve
    narrator "当前状态："
    
    python:
        for key, value in patient_status.items():
            if key == "bp":
                renpy.say(narrator, f"• 血压：{value} mmHg")
            elif key == "spo2":
                renpy.say(narrator, f"• 血氧饱和度：{value}%%")  # 使用%%转义%
            elif key == "血糖":
                renpy.say(narrator, f"• 血糖：{value} mmol/L")
            elif key == "temp":
                renpy.say(narrator, f"• 体温：{value}°C")
            elif key == "gcs":
                renpy.say(narrator, f"• GCS评分：{value}分")
    
    # 决策2-1：病因分析
    menu decision_2_1:
        "根据现有信息，你认为最可能的病因方向是："
        
        "心源性原因（心肌炎/心律失常）":
            $ action_points -= 2
            player "年轻男性，心肌炎或心律失常可能性大。"
            ed_doctor "同意，肌酸激酶显著升高支持心肌损伤。"
            narrator "这个方向需要进一步心脏检查。"
            $ team_points["决策力"] += 1
        
        "代谢性/内分泌原因（电解质紊乱）":
            $ action_points -= 2
            player "低血钾可能导致恶性心律失常。"
            ed_doctor "血钾3.2mmol/L确实偏低，可能是诱因。"
            narrator "需要纠正电解质紊乱。"
            $ team_points["决策力"] += 1
        
        "中毒性/感染性休克":
            $ action_points -= 2
            player "高热、白细胞升高，感染性休克可能性存在。"
            ed_doctor "但毒物筛查阴性，无明确感染灶。"
            narrator "感染证据不够充分。"
            $ team_points["决策力"] -= 1
        
        "神经源性原因（脑卒中/癫痫）":
            $ action_points -= 2
            player "意识障碍持续，需要排除神经系统问题。"
            ed_doctor "但瞳孔对光反射存在，不支持脑疝。"
            narrator "神经科原因待排除。"
    
    # 决策2-2：进一步检查
    host "需要进一步检查来明确诊断！"
    
    menu decision_2_2:
        "接下来应该优先安排哪项检查？"
        
        "急诊床旁超声（eFAST）":
            $ action_points -= 3
            player "立即进行急诊床旁超声检查！"
            if team_points["支援速度"] >= 2:
                emt_tech "超声设备已就位。"
                ed_doctor "检查发现："
                ed_doctor "• 心脏：心室大小正常，收缩功能轻度减低，无心包积液"
                ed_doctor "• 腹部：无游离液体，肝胆胰脾未见异常"
                ed_doctor "• 肺部：B线增多，少量胸腔积液"
                narrator "超声提示轻度心功能不全和肺水肿。"
                $ team_points["支援速度"] += 2
            else:
                narrator "设备准备较慢，延误了检查时机。"
                $ time_elapsed += 10
        
        "急诊心电图（12导联+右室导联）":
            $ action_points -= 2
            player "立即做心电图，包括右室导联！"
            if "急诊专科护士" in team_selection:
                ed_nurse "心电图完成："
                ed_nurse "• 广泛导联ST段抬高（V1-V4最明显）"
                ed_nurse "• 右室导联V4R ST段抬高>1mm"
                ed_nurse "• 完全性右束支传导阻滞"
                narrator "心电图提示急性前壁心肌梗死，可能累及右室！"
                $ diagnosis_found = True
                $ diagnosis_correct = True
                $ team_points["执行效率"] += 3
            else:
                narrator "心电图操作不规范，需要重复检查..."
                $ time_elapsed += 5
        
        "急诊头颅CT":
            $ action_points -= 4
            player "安排急诊头颅CT排除脑出血。"
            if team_points["支援速度"] >= 3:
                emt_tech "护送患者至CT室。"
                narrator "CT结果显示："
                narrator "• 脑实质未见出血或梗死"
                narrator "• 轻度脑水肿"
                narrator "但转运期间患者生命体征波动，血压下降。"
                $ patient_status["bp"] = "80/45"
                $ time_elapsed += 25
                $ team_points["支援速度"] += 1
        
        "心肌损伤标志物复查":
            $ action_points -= 2
            player "复查肌钙蛋白和肌酸激酶同工酶。"
            ed_nurse "抽血送检，需要等待45分钟出结果。"
            narrator "检测结果回报需要时间，可能延误治疗。"
            $ time_elapsed += 45
    
    # 如果诊断正确
    if diagnosis_correct:
        narrator "【重要发现！】"
        narrator "心电图明确显示：急性前壁心肌梗死，右室受累。"
        narrator "这对于年轻患者极为罕见！"
        
        host "诊断要点："
        host "1. 年轻男性，无传统冠心病危险因素"
        host "2. 连续熬夜72小时诱发"
        host "3. 心电图符合急性前壁心梗表现"
        host "4. 肌酸激酶显著升高"
        
        player "立即启动心梗抢救流程！"
        
        # 决策2-3：心梗处理
        menu decision_2_3:
            "对于这位年轻的心梗患者，你的关键治疗决策是："
            
            "立即联系心内科准备急诊PCI":
                $ action_points -= 4
                player "立即联系心导管室，准备急诊冠脉介入！"
                if team_points["决策力"] >= 6:
                    ed_doctor "心内科已响应，导管室准备中。"
                    narrator "这是最快速有效的再灌注治疗。"
                    $ team_points["决策力"] += 3
                else:
                    narrator "决策犹豫，联系不够及时..."
                    $ time_elapsed += 15
            
            "先给予强化药物治疗再评估":
                $ action_points -= 3
                player "给予双联抗血小板、抗凝、他汀强化治疗。"
                ed_nurse "给予阿司匹林300mg、氯吡格雷300mg、低分子肝素。"
                narrator "药物治疗已开始，但再灌注延迟可能影响预后。"
                $ time_elapsed += 30
            
            "先完善冠脉CTA检查":
                $ action_points -= 4
                player "安排冠脉CTA明确病变情况。"
                narrator "CTA检查耗时较长，可能延误再灌注时机。"
                $ time_elapsed += 60
    
    else:
        # 如果诊断未明确
        host "病因仍未明确，需要进一步检查！"
        narrator "患者状态不稳定，时间紧迫。"
        
        menu decision_2_4:
            "下一步检查方向："
            
            "心脏磁共振（CMR）":
                $ action_points -= 5
                player "安排心脏磁共振评估心肌病变。"
                narrator "MRI检查需要转运和长时间扫描，风险较高。"
                $ patient_status["bp"] = "78/43"
                $ time_elapsed += 90
            
            "冠脉造影（金标准）":
                $ action_points -= 4
                player "直接进行诊断性冠脉造影！"
                narrator "造影确诊：左前降支近端完全闭塞。"
                $ diagnosis_found = True
                $ diagnosis_correct = True
                narrator "但决策延迟了[time_elapsed]分钟..."
            
            "心肌活检":
                $ action_points -= 6
                player "进行心内膜心肌活检明确病因。"
                narrator "有创操作风险高，结果需要数天..."
                $ time_elapsed += 120
    
    jump decision_point_3

# ========== 决策点3：多学科协作与稳定 ==========
label decision_point_3:
    scene bg_er_control with dissolve
    
    narrator "【时间：+[time_elapsed]分钟】"
    host "决策点3：多学科协作与稳定"
    
    if diagnosis_correct:
        host "诊断已明确：急性前壁心肌梗死（累及右室）"
        host "需要多学科协作进行最终处理。"
    else:
        host "诊断仍未明确，患者状态恶化..."
        host "需要多学科会诊寻找病因。"
    
    # 决策3-1：多学科协作
    menu decision_3_1:
        "如何组织多学科协作？"
        
        "立即召开急诊MDT会诊":
            $ action_points -= 3
            player "召集心内科、ICU、心外科、影像科紧急会诊！"
            narrator "多学科专家正在集结..."
            
            if team_points["决策力"] >= 7:
                narrator "高效协作建立！"
                narrator "• 心内科：准备急诊PCI"
                narrator "• ICU：准备术后监护"
                narrator "• 心外科：备台，必要时手术"
                narrator "• 影像科：提供实时影像支持"
                $ team_points["决策力"] += 4
            else:
                narrator "协调不够顺畅，专家响应延迟..."
                $ time_elapsed += 30
        
        "直接转入心导管室":
            $ action_points -= 3
            player "直接转运至导管室，术中根据需要呼叫会诊。"
            if team_points["支援速度"] >= 4:
                emt_tech "转运准备完成，生命支持设备就绪。"
                narrator "快速转运至导管室，节省了宝贵时间。"
                $ time_elapsed += 5
                $ team_points["支援速度"] += 2
            else:
                narrator "转运过程中监护设备报警频繁..."
                $ patient_status["hr"] = 125
                $ patient_status["bp"] = "75/40"
                $ time_elapsed += 20
        
        "先稳定生命体征再转科":
            $ action_points -= 3
            player "在急诊室进一步稳定后再转科。"
            narrator "继续液体复苏和血管活性药物支持..."
            $ time_elapsed += 45
            if team_points["氧合支持"] >= 6:
                narrator "生命体征逐渐稳定。"
                $ patient_status["bp"] = "95/60"
                $ patient_status["hr"] = 105
            else:
                narrator "生命体征仍不稳定..."
                $ patient_status["bp"] = "80/45"
    
    # 决策3-2：并发症预防
    host "患者可能出现多种并发症，需要预防性处理！"
    
    menu decision_3_2:
        "最需要预防的并发症是："
        
        "恶性心律失常（室颤/室速）":
            $ action_points -= 2
            player "连接除颤电极，准备抗心律失常药物。"
            if team_points["执行效率"] >= 8:
                ed_nurse "除颤仪待机状态，胺碘酮静脉泵入准备。"
                narrator "心律失常预防措施到位。"
                $ team_points["执行效率"] += 2
            
            # 模拟心律失常发生
            narrator "【突发！】室颤发生！"
            menu:
                "立即电除颤":
                    player "立即200J双相波电除颤！"
                    narrator "除颤成功，恢复窦性心律。"
                    $ action_points -= 2
                
                "先进行CPR2分钟再除颤":
                    player "立即CPR2分钟后评估心律！"
                    narrator "CPR后心律仍为室颤，除颤延迟..."
                    $ patient_status["gcs"] = 3  # 意识未恢复
                    $ action_points -= 3
        
        "心源性休克":
            $ action_points -= 3
            player "准备主动脉内球囊反搏（IABP）支持！"
            if "呼吸治疗师" in team_selection and team_points["氧合支持"] >= 6:
                rt_therapist "IABP设备准备完成，协助血流动力学支持。"
                narrator "循环支持到位，血压稳定。"
                $ patient_status["bp"] = "100/65"
                $ team_points["氧合支持"] += 3
            else:
                narrator "缺乏IABP支持条件，循环不稳定..."
                $ patient_status["bp"] = "85/50"
        
        "多器官功能衰竭":
            $ action_points -= 3
            player "启动肾脏保护策略，监测器官功能。"
            narrator "持续监测尿量、肝肾功能、凝血功能..."
            
            if "急诊专科护士" in team_selection and team_selection.count("急诊专科护士") >= 2:
                ed_nurse "密切监测中，每小时记录出入量。"
                narrator "早期发现肾功能损伤迹象。"
                $ team_points["执行效率"] += 3
            else:
                narrator "监测不够频繁，肾功能恶化..."
                $ patient_status["肌酐"] = "220 μmol/L"
    
    # 决策3-3：长期预后考虑
    host "抢救进入稳定阶段，需要考虑长期预后。"
    
    menu decision_3_3:
        "对于这位年轻患者的长期管理，你的建议是："
        
        "基因检测寻找遗传性心脏病":
            $ action_points -= 2
            player "建议进行基因检测，排除遗传性心肌病。"
            narrator "这是非常重要的病因探查，可能影响家族成员。"
            if team_points["决策力"] >= 8:
                narrator "决策体现了全面性和前瞻性。"
                $ team_points["决策力"] += 3
            else:
                narrator "长期管理考虑不足..."
        
        "康复计划与生活方式干预":
            $ action_points -= 2
            player "制定心脏康复计划，强调生活方式改变。"
            narrator "预防再发事件的关键措施。"
            if "呼吸治疗师" in team_selection:
                rt_therapist "可以纳入早期呼吸康复训练。"
                narrator "多学科康复团队组建中..."
                $ team_points["氧合支持"] += 2
        
        "心理支持与社会回归":
            $ action_points -= 1
            player "安排心理评估，帮助患者回归正常生活。"
            narrator "年轻患者需要心理社会支持。"
            narrator "但医疗团队中缺乏心理专业人员..."
    
    # 抢救结束
    narrator "【时间：+[time_elapsed]分钟】"
    narrator "抢救告一段落，患者准备转入ICU或心导管室。"
    
    jump evaluation_scene

# ========== 评价场景 ==========
label evaluation_scene:
    scene bg_er_control with dissolve
    
    host "抢救模拟结束！现在进行综合评价。"
    
    # 计算总分
    python:
        total_score = 0
        
        # 基础分
        base_score = 60
        
        # 时间效率分
        time_score = 0
        if time_elapsed < 60:
            time_score = 30
        elif time_elapsed < 120:
            time_score = 20
        elif time_elapsed < 180:
            time_score = 10
        else:
            time_score = 0
        
        # 诊断准确分
        diagnosis_score = 0
        if diagnosis_correct:
            if time_elapsed < 60:
                diagnosis_score = 40
            elif time_elapsed < 120:
                diagnosis_score = 30
            else:
                diagnosis_score = 20
        elif diagnosis_found:
            diagnosis_score = 10
        else:
            diagnosis_score = 0
        
        # 团队协作分
        team_score = 0
        for value in team_points.values():
            team_score += value
        
        # 行动效率分
        action_efficiency = (action_points / 10.0) * 20 if action_points > 0 else 0
        
        total_score = base_score + time_score + diagnosis_score + team_score + action_efficiency
        total_score = min(100, total_score)  # 上限100分
    
    narrator "========== 抢救报告 =========="
    if diagnosis_correct:
        narrator "• 最终诊断：诊断明确，急性心肌梗死"
    else:
        narrator "• 最终诊断：诊断不明确"
    narrator "• 总耗时：[time_elapsed]分钟"
    narrator "• 团队技能总分：[team_score]分"
    narrator "• 剩余行动点：[action_points]"
    
    narrator "\n========== 详细评分 =========="
    narrator "基础分：60分"
    narrator "时间效率：[time_score]分（耗时[time_elapsed]分钟）"
    narrator "诊断准确：[diagnosis_score]分"
    narrator "团队协作：[team_score]分"
    narrator "行动效率：[int(action_efficiency)]分"
    narrator "\n总分：[int(total_score)]/100分"
    
    # 评价等级
    if total_score >= 90:
        host "★★★★★ 卓越指挥官 ★★★★★"
        host "你的表现堪称完美！决策迅速准确，团队协作高效，深刻理解了BLS为ALS创造的宝贵机会。"
    elif total_score >= 80:
        host "★★★★☆ 优秀指挥官 ★★★★☆"
        host "表现优秀！掌握了急诊抢救的核心流程，但在细节处理和时机把握上还有提升空间。"
    elif total_score >= 70:
        host "★★★☆☆ 合格指挥官 ★★★☆☆"
        host "基本完成抢救任务，但在多学科协作和病因探查方面需要加强学习。"
    elif total_score >= 60:
        host "★★☆☆☆ 学习型指挥官 ★★☆☆☆"
        host "完成了基础抢救，但在关键时刻的决策和团队协调能力有待提高。"
    else:
        host "★☆☆☆☆ 需要更多练习 ★☆☆☆☆"
        host "建议重新学习急诊抢救流程和多学科协作原则。"
    
    # 教学要点总结
    host "\n========== 教学要点总结 =========="
    host "1. 黄金时间概念：院前高质量BLS为院内ALS赢得了宝贵机会"
    host "2. 系统性评估：ABCDE评估法是急诊抢救的基石"
    host "3. 病因导向治疗：明确病因才能精准干预"
    host "4. 多学科协作：现代急诊医学的核心模式"
    host "5. 年轻心梗特点：无传统危险因素，需考虑非典型病因"
    
    # BLS与ALS衔接的重要性
    host "\n========== 核心启示 =========="
    host "本次模拟展示了院前基础生命支持（BLS）与院内高级生命支持（ALS）的无缝衔接："
    host "• 同学的及时CPR维持了脑灌注"
    host "• AED早期除颤恢复了有效心律"
    host "• 这些基础措施为你争取了进行高级干预的窗口期"
    host "• 你的任务是充分利用这个窗口，找出并解决根本问题"
    
    volunteer "记住：每一次成功的院内抢救，都始于院前第一响应者的正确行动。"
    volunteer "而院内抢救的成功，又能激励更多人学习急救技能，形成良性循环。"
    
    # 结束选项
    menu:
        "重新开始游戏":
            jump start
        
        "查看详细分析报告":
            jump detailed_report
        
        "返回主菜单":
            return

label detailed_report:
    scene black with dissolve
    
    narrator "========== 详细分析报告 =========="
    
    narrator "\n【患者最终状态】"
    
    python:
        for key, value in patient_status.items():
            if key == "gcs":
                if value <= 3:
                    consciousness = "深昏迷"
                elif value <= 8:
                    consciousness = "中昏迷"
                elif value <= 12:
                    consciousness = "浅昏迷"
                else:
                    consciousness = "清醒"
                renpy.say(narrator, f"• 意识状态：GCS {value}分（{consciousness}）")
            elif key == "bp":
                if "/" in value:
                    systolic = int(value.split('/')[0])
                else:
                    systolic = 0
                if systolic < 90:
                    bp_status = "休克血压"
                elif systolic < 100:
                    bp_status = "偏低"
                else:
                    bp_status = "正常偏低"
                renpy.say(narrator, f"• 血压：{value} mmHg（{bp_status}）")
            elif key == "spo2":
                if value >= 95:
                    oxygen_status = "正常"
                elif value >= 90:
                    oxygen_status = "轻度低氧"
                else:
                    oxygen_status = "中重度低氧"
                renpy.say(narrator, f"• 血氧饱和度：{value}%%（{oxygen_status}）")  # 使用%%转义%
    
    narrator "\n【团队表现分析】"
    
    python:
        strengths = []
        weaknesses = []
        
        if team_points["决策力"] >= 6:
            strengths.append("决策迅速准确")
        else:
            weaknesses.append("决策犹豫或错误")
        
        if team_points["执行效率"] >= 6:
            strengths.append("执行高效有序")
        else:
            weaknesses.append("执行效率较低")
        
        if team_points["氧合支持"] >= 5:
            strengths.append("呼吸支持专业")
        else:
            weaknesses.append("呼吸管理不足")
        
        if team_points["支援速度"] >= 3:
            strengths.append("后勤保障及时")
        else:
            weaknesses.append("支援响应缓慢")
    
    if strengths:
        narrator "优势："
        python:
            for strength in strengths:
                renpy.say(narrator, f"• {strength}")
    
    if weaknesses:
        narrator "\n改进空间："
        python:
            for weakness in weaknesses:
                renpy.say(narrator, f"• {weakness}")
    
    narrator "\n【关键决策回顾】"
    narrator "1. 团队组建：决定了抢救的基础能力"
    narrator "2. 初步评估：快速识别主要问题"
    narrator "3. 病因探查：明确诊断方向"
    narrator "4. 多学科协作：整合专业资源"
    
    narrator "\n【BLS-ALS衔接关键点】"
    narrator "• 院前：高质量CPR + 早期除颤 = 恢复自主循环"
    narrator "• 转运：持续生命支持 + 信息传递"
    narrator "• 院内：系统评估 + 病因治疗 + 多学科协作"
    
    narrator "\n【年轻心梗的特殊性】"
    narrator "• 病因：可能为非动脉粥样硬化原因（血管痉挛、血栓、夹层）"
    narrator "• 诊断：需要更积极检查，不能因年轻而排除"
    narrator "• 治疗：再灌注同样关键，且需要病因治疗"
    narrator "• 预后：长期管理更重要（遗传咨询、生活方式）"
    
    host "希望这次模拟能让你深刻体会到："
    host "院前急救与院内抢救是一个连续的整体，"
    host "每个环节都至关重要，每个决策都影响生死。"
    
    jump evaluation_scene